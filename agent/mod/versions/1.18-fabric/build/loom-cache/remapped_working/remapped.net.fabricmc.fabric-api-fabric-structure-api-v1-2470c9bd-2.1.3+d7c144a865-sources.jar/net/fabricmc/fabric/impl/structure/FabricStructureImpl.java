/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.structure;

import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.fabricmc.fabric.mixin.structure.StructuresConfigAccessor;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.level.levelgen.feature.configurations.StructureFeatureConfiguration;

public class FabricStructureImpl implements ModInitializer {
	//Keeps a map of structures to structure configs for purposes of initializing the flat chunk generator
	public static final Map<StructureFeature<?>, StructureFeatureConfiguration> FLAT_STRUCTURE_TO_CONFIG_MAP = new HashMap<>();

	//Keeps a map of structures to structure configs.
	public static final Map<StructureFeature<?>, StructureFeatureConfiguration> STRUCTURE_TO_CONFIG_MAP = new HashMap<>();

	@Override
	public void onInitialize() {
		ServerWorldEvents.LOAD.register((server, world) -> {
			// Need temp map as some mods use custom chunk generators with immutable maps in themselves.
			Map<StructureFeature<?>, StructureFeatureConfiguration> tempMap = new HashMap<>(world.getChunkSource().getGenerator().getSettings().structureConfig());

			tempMap.putAll(STRUCTURE_TO_CONFIG_MAP);

			//Make it immutable again
			ImmutableMap<StructureFeature<?>, StructureFeatureConfiguration> immutableMap = ImmutableMap.copyOf(tempMap);
			((StructuresConfigAccessor) world.getChunkSource().getGenerator().getSettings()).setStructures(immutableMap);
		});
	}
}
