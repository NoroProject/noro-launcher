/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.tool.attribute.handlers;

import java.util.List;

import org.jetbrains.annotations.NotNull;
import net.fabricmc.fabric.api.tool.attribute.v1.DynamicAttributeTool;
import net.fabricmc.fabric.impl.tool.attribute.ToolManagerImpl;
import net.minecraft.tags.Tag;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TieredItem;
import net.minecraft.world.level.block.state.BlockState;

/**
 * This handler handles items that are a subclass of {@link DynamicAttributeTool} by using the
 * vanilla {@link Item#isCorrectToolForDrops(BlockState)} with a custom fake tool material to use the mining level
 * from {@link DynamicAttributeTool#getMiningLevel(Tag, BlockState, ItemStack, LivingEntity)}.
 *
 * <p>Only applicable to blocks that are vanilla or share the material that is handled by their vanilla tool.</p>
 */
public class ModdedToolsVanillaBlocksToolHandler implements ToolManagerImpl.ToolHandler {
	private final List<Item> vanillaItems;

	public ModdedToolsVanillaBlocksToolHandler(List<Item> vanillaItems) {
		this.vanillaItems = vanillaItems;
	}

	private TieredItem getVanillaItem(int miningLevel) {
		if (miningLevel < 0) return (TieredItem) vanillaItems.get(0);
		if (miningLevel >= vanillaItems.size()) return (TieredItem) vanillaItems.get(vanillaItems.size() - 1);
		return (TieredItem) vanillaItems.get(miningLevel);
	}

	@NotNull
	@Override
	public InteractionResult isEffectiveOn(Tag<Item> tag, BlockState state, ItemStack stack, LivingEntity user) {
		if (stack.getItem() instanceof DynamicAttributeTool) {
			if (ToolManagerImpl.entryNullable(state.getBlock()) != null) {
				// Block is a modded block, and we should ignore it
				return InteractionResult.PASS;
			}

			// Gets the mining level from our modded tool
			int miningLevel = ((DynamicAttributeTool) stack.getItem()).getMiningLevel(tag, state, stack, user);
			if (miningLevel < 0) return InteractionResult.PASS;

			TieredItem vanillaItem = getVanillaItem(miningLevel);
			return vanillaItem.isCorrectToolForDrops(state) ? InteractionResult.SUCCESS : InteractionResult.PASS;
		}

		return InteractionResult.PASS;
	}

	@NotNull
	@Override
	public InteractionResultHolder<Float> getMiningSpeedMultiplier(Tag<Item> tag, BlockState state, ItemStack stack, LivingEntity user) {
		if (stack.getItem() instanceof DynamicAttributeTool) {
			// Gets the mining level from our modded tool
			int miningLevel = ((DynamicAttributeTool) stack.getItem()).getMiningLevel(tag, state, stack, user);
			if (miningLevel < 0) return null;

			float moddedToolSpeed = ((DynamicAttributeTool) stack.getItem()).getMiningSpeedMultiplier(tag, state, stack, user);
			TieredItem firstVanillaItem = getVanillaItem(miningLevel);
			TieredItem secondVanillaItem = getVanillaItem(miningLevel + 1 >= vanillaItems.size() ? vanillaItems.size() - 2 : miningLevel + 1);

			float firstSpeed = firstVanillaItem.getDestroySpeed(new ItemStack(firstVanillaItem, 1), state);
			float secondSpeed = secondVanillaItem.getDestroySpeed(new ItemStack(secondVanillaItem, 1), state);
			boolean hasForcedSpeed = firstSpeed == secondSpeed && firstSpeed >= 1.0F;

			// Has forced speed, which as actions like swords breaking cobwebs.
			if (hasForcedSpeed) {
				return secondSpeed != 1.0F ? InteractionResultHolder.success(secondSpeed) : InteractionResultHolder.pass(1.0F);
			}

			// We adjust the mining speed according to the ratio for the closest tool.
			float adjustedMiningSpeed = firstSpeed / firstVanillaItem.getTier().getSpeed() * moddedToolSpeed;
			return adjustedMiningSpeed != 1.0F ? InteractionResultHolder.success(adjustedMiningSpeed) : InteractionResultHolder.pass(1.0F);
		}

		return InteractionResultHolder.pass(1.0F);
	}
}
