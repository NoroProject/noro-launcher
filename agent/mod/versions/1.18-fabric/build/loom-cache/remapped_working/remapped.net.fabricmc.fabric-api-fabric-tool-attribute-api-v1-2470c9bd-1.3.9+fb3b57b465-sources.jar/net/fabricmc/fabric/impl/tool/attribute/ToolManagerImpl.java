/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.tool.attribute;

import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;

import com.google.common.collect.ImmutableMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.fabricmc.fabric.api.mininglevel.v1.FabricMineableTags;
import net.fabricmc.fabric.api.mininglevel.v1.MiningLevelManager;
import net.fabricmc.fabric.api.tool.attribute.v1.DynamicAttributeTool;
import net.fabricmc.fabric.api.tool.attribute.v1.FabricToolTags;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.Tag;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public final class ToolManagerImpl {
	private static final Map<Tag<Item>, Tag<Block>> MINEABLE_TAG_BY_TOOL = ImmutableMap.<Tag<Item>, Tag<Block>>builder()
			// Vanilla mineable tags
			.put(FabricToolTags.AXES, BlockTags.MINEABLE_WITH_AXE)
			.put(FabricToolTags.HOES, BlockTags.MINEABLE_WITH_HOE)
			.put(FabricToolTags.PICKAXES, BlockTags.MINEABLE_WITH_PICKAXE)
			.put(FabricToolTags.SHOVELS, BlockTags.MINEABLE_WITH_SHOVEL)
			// Fabric mineable tags
			.put(FabricToolTags.SHEARS, FabricMineableTags.SHEARS_MINEABLE)
			.put(FabricToolTags.SWORDS, FabricMineableTags.SWORD_MINEABLE)
			.build();

	public interface Entry {
		void setBreakByHand(boolean value);

		void putBreakByTool(Tag<Item> tag, int miningLevel);

		int getMiningLevel(Tag<Item> tag);
	}

	private static class EntryImpl implements Entry {
		private final Block block;
		private Tag<Item>[] tags = new Tag[0];
		private int[] tagLevels = new int[0];
		private TriState defaultValue = TriState.DEFAULT;

		private EntryImpl(Block block) {
			this.block = block;
		}

		@Override
		public void setBreakByHand(boolean value) {
			this.defaultValue = TriState.of(value);
		}

		@Override
		public void putBreakByTool(Tag<Item> tag, int miningLevel) {
			tag(tag); // Generate tag entry

			for (int i = 0; i < tags.length; i++) {
				if (tags[i] == tag) {
					tagLevels[i] = miningLevel;
					return;
				}
			}

			tags = Arrays.copyOf(tags, tags.length + 1);
			tags[tags.length - 1] = tag;

			tagLevels = Arrays.copyOf(tagLevels, tagLevels.length + 1);
			tagLevels[tagLevels.length - 1] = miningLevel;
		}

		@Override
		public int getMiningLevel(Tag<Item> tag) {
			// Implementation detail: the actual logic does not check the state.
			// TODO: This should be changed some day to respect the block state,
			//   but the entry code is quite coupled in blocks instead of states.
			int miningLevel = MiningLevelManager.getRequiredMiningLevel(block.defaultBlockState());

			for (int i = 0; i < tags.length; i++) {
				if (tags[i] == tag) {
					miningLevel = Math.max(miningLevel, tagLevels[i]);
				}
			}

			for (Tag<Item> key : MINEABLE_TAG_BY_TOOL.keySet()) {
				if (tag == key && MINEABLE_TAG_BY_TOOL.get(key).contains(block)) {
					miningLevel = Math.max(miningLevel, 0);
				}
			}

			return miningLevel;
		}
	}

	private static final Map<Tag<Item>, Event<ToolHandler>> HANDLER_MAP = new HashMap<>();
	private static final Event<ToolHandler> GENERAL_TOOLS_HANDLER = EventFactory.createArrayBacked(ToolHandler.class, ToolManagerImpl::toolHandlerInvoker);

	private static final Map<Block, EntryImpl> ENTRIES = new IdentityHashMap<>();

	/**
	 * Returns a event for the tag provided, creates a new event if it does not exist.
	 *
	 * @param tag the tag provided for the tool
	 * @return the event callback.
	 */
	public static Event<ToolHandler> tag(Tag<Item> tag) {
		for (Map.Entry<Tag<Item>, Event<ToolHandler>> entry : HANDLER_MAP.entrySet()) {
			if ((tag instanceof Tag.Named ? (((Tag.Named<Item>) entry.getKey()).getName().equals(((Tag.Named<Item>) tag).getName())) : entry.getKey().equals(tag))) {
				return entry.getValue();
			}
		}

		HANDLER_MAP.put(tag, EventFactory.createArrayBacked(ToolHandler.class, ToolManagerImpl::toolHandlerInvoker));
		return HANDLER_MAP.get(tag);
	}

	/**
	 * Returns a event used for every tag registered.
	 *
	 * @return the event callback.
	 */
	public static Event<ToolHandler> general() {
		return GENERAL_TOOLS_HANDLER;
	}

	private static ToolHandler toolHandlerInvoker(ToolHandler[] toolHandlers) {
		return new ToolHandler() {
			@NotNull
			@Override
			public InteractionResult isEffectiveOn(Tag<Item> tag, BlockState state, ItemStack stack, LivingEntity user) {
				for (ToolHandler toolHandler : toolHandlers) {
					InteractionResult effectiveOn = Objects.requireNonNull(toolHandler.isEffectiveOn(tag, state, stack, user));

					if (effectiveOn != InteractionResult.PASS) {
						return effectiveOn;
					}
				}

				return InteractionResult.PASS;
			}

			@NotNull
			@Override
			public InteractionResultHolder<Float> getMiningSpeedMultiplier(Tag<Item> tag, BlockState state, ItemStack stack, LivingEntity user) {
				for (ToolHandler toolHandler : toolHandlers) {
					InteractionResultHolder<Float> miningSpeedMultiplier = Objects.requireNonNull(toolHandler.getMiningSpeedMultiplier(tag, state, stack, user));

					if (miningSpeedMultiplier.getResult() != InteractionResult.PASS) {
						return miningSpeedMultiplier;
					}
				}

				return InteractionResultHolder.pass(1f);
			}
		};
	}

	public static Entry entry(Block block) {
		return ENTRIES.computeIfAbsent(block, (bb) -> new EntryImpl(block));
	}

	@Nullable
	public static Entry entryNullable(Block block) {
		return ENTRIES.get(block);
	}

	@Deprecated
	public static void registerBreakByHand(Block block, boolean value) {
		entry(block).setBreakByHand(value);
	}

	@Deprecated
	public static void registerBreakByTool(Block block, Tag<Item> tag, int miningLevel) {
		entry(block).putBreakByTool(tag, miningLevel);
	}

	/**
	 * Hook for ItemStack.isEffectiveOn and similar methods.
	 */
	public static boolean handleIsEffectiveOnIgnoresVanilla(BlockState state, ItemStack stack, @Nullable LivingEntity user, boolean vanillaResult) {
		for (Map.Entry<Tag<Item>, Event<ToolHandler>> eventEntry : HANDLER_MAP.entrySet()) {
			if (stack.is(eventEntry.getKey())) {
				InteractionResult effective = eventEntry.getValue().invoker().isEffectiveOn(eventEntry.getKey(), state, stack, user);
				if (effective.consumesAction()) return true;
				effective = general().invoker().isEffectiveOn(eventEntry.getKey(), state, stack, user);
				if (effective.consumesAction()) return true;
			}
		}

		EntryImpl entry = (EntryImpl) entryNullable(state.getBlock());

		return (entry != null && entry.defaultValue.get()) || (entry == null && vanillaResult);
	}

	public static float handleBreakingSpeedIgnoresVanilla(BlockState state, ItemStack stack, @Nullable LivingEntity user) {
		float breakingSpeed = 0f;
		Tag<Item> handledTag = null;
		boolean handled = false;

		for (Map.Entry<Tag<Item>, Event<ToolHandler>> eventEntry : HANDLER_MAP.entrySet()) {
			if (stack.is(eventEntry.getKey())) {
				InteractionResultHolder<Float> speedMultiplier = Objects.requireNonNull(eventEntry.getValue().invoker().getMiningSpeedMultiplier(eventEntry.getKey(), state, stack, user));

				if (speedMultiplier.getResult().consumesAction()) {
					handled = true;

					if (speedMultiplier.getObject() > breakingSpeed) {
						breakingSpeed = speedMultiplier.getObject();
						handledTag = eventEntry.getKey();
					}
				}

				speedMultiplier = Objects.requireNonNull(general().invoker().getMiningSpeedMultiplier(eventEntry.getKey(), state, stack, user));

				if (speedMultiplier.getResult().consumesAction()) {
					handled = true;

					if (speedMultiplier.getObject() > breakingSpeed) {
						breakingSpeed = speedMultiplier.getObject();
						handledTag = eventEntry.getKey();
					}
				}
			}
		}

		// Give it a default speed if it is not handled.
		breakingSpeed = handled ? breakingSpeed : 1f;

		if (stack.getItem() instanceof DynamicAttributeTool) {
			breakingSpeed = ((DynamicAttributeTool) stack.getItem()).postProcessMiningSpeed(handledTag, state, stack, user, breakingSpeed, handled);
		}

		return breakingSpeed;
	}

	/**
	 * The handler to handle tool speed and effectiveness.
	 *
	 * @see net.fabricmc.fabric.impl.tool.attribute.ToolHandlers for default handlers.
	 */
	public interface ToolHandler {
		/**
		 * Determines whether this handler is active and effective of the tools.
		 *
		 * @param tag   the tag involved
		 * @param state the block state to break
		 * @param stack the item stack breaking the block
		 * @param user  the user involved in breaking the block, null if not applicable.
		 * @return the result of effectiveness
		 */
		@NotNull
		default InteractionResult isEffectiveOn(Tag<Item> tag, BlockState state, ItemStack stack, @Nullable LivingEntity user) {
			return InteractionResult.PASS;
		}

		/**
		 * Determines the mining speed multiplier of the tools.
		 *
		 * @param tag   the tag involved
		 * @param state the block state to break
		 * @param stack the item stack breaking the block
		 * @param user  the user involved in breaking the block, null if not applicable.
		 * @return the result of mining speed.
		 */
		@NotNull
		default InteractionResultHolder<Float> getMiningSpeedMultiplier(Tag<Item> tag, BlockState state, ItemStack stack, @Nullable LivingEntity user) {
			return InteractionResultHolder.pass(1.0F);
		}
	}
}
