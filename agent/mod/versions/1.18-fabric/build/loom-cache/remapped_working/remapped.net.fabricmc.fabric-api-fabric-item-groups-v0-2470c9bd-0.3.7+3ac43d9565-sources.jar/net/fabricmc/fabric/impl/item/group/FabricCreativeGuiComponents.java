/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.item.group;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;

public class FabricCreativeGuiComponents {
	private static final ResourceLocation BUTTON_TEX = new ResourceLocation("fabric", "textures/gui/creative_buttons.png");
	public static final Set<CreativeModeTab> COMMON_GROUPS = new HashSet<>();

	static {
		COMMON_GROUPS.add(CreativeModeTab.TAB_SEARCH);
		COMMON_GROUPS.add(CreativeModeTab.TAB_INVENTORY);
		COMMON_GROUPS.add(CreativeModeTab.TAB_HOTBAR);
	}

	public static class ItemGroupButtonWidget extends Button {
		CreativeGuiExtensions extensions;
		CreativeModeInventoryScreen gui;
		Type type;

		public ItemGroupButtonWidget(int x, int y, Type type, CreativeGuiExtensions extensions) {
			super(x, y, 11, 10, type.text, (bw) -> type.clickConsumer.accept(extensions));
			this.extensions = extensions;
			this.type = type;
			this.gui = (CreativeModeInventoryScreen) extensions;
		}

		@Override
		public void render(PoseStack matrixStack, int mouseX, int mouseY, float float_1) {
			this.isHovered = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
			this.visible = extensions.fabric_isButtonVisible(type);
			this.active = extensions.fabric_isButtonEnabled(type);

			if (this.visible) {
				int u = active && this.isHoveredOrFocused() ? 22 : 0;
				int v = active ? 0 : 10;

				RenderSystem.setShaderTexture(0, BUTTON_TEX);
				RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
				this.blit(matrixStack, this.x, this.y, u + (type == Type.NEXT ? 11 : 0), v, 11, 10);

				if (this.isHovered) {
					gui.renderTooltip(matrixStack, new TranslatableComponent("fabric.gui.creativeTabPage", extensions.fabric_currentPage() + 1, ((CreativeModeTab.TABS.length - 12) / 9) + 2), mouseX, mouseY);
				}
			}
		}
	}

	public enum Type {
		NEXT(new TextComponent(">"), CreativeGuiExtensions::fabric_nextPage),
		PREVIOUS(new TextComponent("<"), CreativeGuiExtensions::fabric_previousPage);

		Component text;
		Consumer<CreativeGuiExtensions> clickConsumer;

		Type(Component text, Consumer<CreativeGuiExtensions> clickConsumer) {
			this.text = text;
			this.clickConsumer = clickConsumer;
		}
	}
}
