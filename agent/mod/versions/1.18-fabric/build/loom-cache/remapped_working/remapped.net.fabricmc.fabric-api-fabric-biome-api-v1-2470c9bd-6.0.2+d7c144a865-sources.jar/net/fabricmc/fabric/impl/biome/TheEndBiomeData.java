/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.biome;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.TheEndBiomeSource;
import net.minecraft.world.level.levelgen.synth.ImprovedNoise;
import com.google.common.base.Preconditions;
import org.jetbrains.annotations.ApiStatus;

/**
 * Internal data for modding Vanilla's {@link TheEndBiomeSource}.
 */
@ApiStatus.Internal
public final class TheEndBiomeData {
	// Cached sets of the biomes that would generate from Vanilla's default biome source without consideration
	// for data packs (as those would be distinct biome sources).
	private static final Set<ResourceKey<Biome>> THE_END_BIOMES = new HashSet<>();

	private static final Map<ResourceKey<Biome>, WeightedBiomePicker> END_BIOMES_MAP = new IdentityHashMap<>();
	private static final Map<ResourceKey<Biome>, WeightedBiomePicker> END_MIDLANDS_MAP = new IdentityHashMap<>();
	private static final Map<ResourceKey<Biome>, WeightedBiomePicker> END_BARRENS_MAP = new IdentityHashMap<>();

	static {
		END_BIOMES_MAP.computeIfAbsent(Biomes.THE_END, key -> new WeightedBiomePicker()).addBiome(Biomes.THE_END, 1.0);
		END_BIOMES_MAP.computeIfAbsent(Biomes.END_HIGHLANDS, key -> new WeightedBiomePicker()).addBiome(Biomes.END_HIGHLANDS, 1.0);
		END_BIOMES_MAP.computeIfAbsent(Biomes.SMALL_END_ISLANDS, key -> new WeightedBiomePicker()).addBiome(Biomes.SMALL_END_ISLANDS, 1.0);

		END_MIDLANDS_MAP.computeIfAbsent(Biomes.END_HIGHLANDS, key -> new WeightedBiomePicker()).addBiome(Biomes.END_MIDLANDS, 1.0);
		END_BARRENS_MAP.computeIfAbsent(Biomes.END_HIGHLANDS, key -> new WeightedBiomePicker()).addBiome(Biomes.END_BARRENS, 1.0);
	}

	private TheEndBiomeData() {
	}

	public static void addEndBiomeReplacement(ResourceKey<Biome> replaced, ResourceKey<Biome> variant, double weight) {
		Preconditions.checkNotNull(replaced, "replaced biome is null");
		Preconditions.checkNotNull(variant, "variant biome is null");
		Preconditions.checkArgument(weight > 0.0, "Weight is less than or equal to 0.0 (got %s)", weight);
		END_BIOMES_MAP.computeIfAbsent(replaced, key -> new WeightedBiomePicker()).addBiome(variant, weight);
		clearBiomeSourceCache();
	}

	public static void addEndMidlandsReplacement(ResourceKey<Biome> highlands, ResourceKey<Biome> midlands, double weight) {
		Preconditions.checkNotNull(highlands, "highlands biome is null");
		Preconditions.checkNotNull(midlands, "midlands biome is null");
		Preconditions.checkArgument(weight > 0.0, "Weight is less than or equal to 0.0 (got %s)", weight);
		END_MIDLANDS_MAP.computeIfAbsent(highlands, key -> new WeightedBiomePicker()).addBiome(midlands, weight);
		clearBiomeSourceCache();
	}

	public static void addEndBarrensReplacement(ResourceKey<Biome> highlands, ResourceKey<Biome> barrens, double weight) {
		Preconditions.checkNotNull(highlands, "highlands biome is null");
		Preconditions.checkNotNull(barrens, "midlands biome is null");
		Preconditions.checkArgument(weight > 0.0, "Weight is less than or equal to 0.0 (got %s)", weight);
		END_BARRENS_MAP.computeIfAbsent(highlands, key -> new WeightedBiomePicker()).addBiome(barrens, weight);
		clearBiomeSourceCache();
	}

	public static Map<ResourceKey<Biome>, WeightedBiomePicker> getEndBiomesMap() {
		return END_BIOMES_MAP;
	}

	public static Map<ResourceKey<Biome>, WeightedBiomePicker> getEndMidlandsMap() {
		return END_MIDLANDS_MAP;
	}

	public static Map<ResourceKey<Biome>, WeightedBiomePicker> getEndBarrensMap() {
		return END_BARRENS_MAP;
	}

	public static boolean canGenerateInTheEnd(ResourceKey<Biome> biome) {
		if (THE_END_BIOMES.isEmpty()) {
			for (Biome endBiome : new TheEndBiomeSource(BuiltinRegistries.BIOME, 0).possibleBiomes()) {
				BuiltinRegistries.BIOME.getResourceKey(endBiome).ifPresent(THE_END_BIOMES::add);
			}
		}

		return THE_END_BIOMES.contains(biome);
	}

	private static void clearBiomeSourceCache() {
		THE_END_BIOMES.clear(); // Clear cached biome source data
	}

	public static ResourceKey<Biome> pickEndBiome(int biomeX, int biomeY, int biomeZ, ImprovedNoise sampler, ResourceKey<Biome> vanillaKey) {
		ResourceKey<Biome> replacementKey;

		// The x and z of the biome are divided by 64 to ensure custom biomes are large enough; going larger than this]
		// seems to make custom biomes too hard to find.
		if (vanillaKey == Biomes.END_MIDLANDS || vanillaKey == Biomes.END_BARRENS) {
			// Since the highlands picker is statically populated by InternalBiomeData, picker will never be null.
			WeightedBiomePicker highlandsPicker = TheEndBiomeData.getEndBiomesMap().get(Biomes.END_HIGHLANDS);
			ResourceKey<Biome> highlandsKey = highlandsPicker.pickFromNoise(sampler, biomeX / 64.0, 0, biomeZ / 64.0);

			if (vanillaKey == Biomes.END_MIDLANDS) {
				WeightedBiomePicker midlandsPicker = TheEndBiomeData.getEndMidlandsMap().get(highlandsKey);
				replacementKey = (midlandsPicker == null) ? vanillaKey : midlandsPicker.pickFromNoise(sampler, biomeX / 64.0, 0, biomeZ / 64.0);
			} else {
				WeightedBiomePicker barrensPicker = TheEndBiomeData.getEndBarrensMap().get(highlandsKey);
				replacementKey = (barrensPicker == null) ? vanillaKey : barrensPicker.pickFromNoise(sampler, biomeX / 64.0, 0, biomeZ / 64.0);
			}
		} else {
			// Since the main island and small islands pickers are statically populated by InternalBiomeData, picker will never be null.
			WeightedBiomePicker picker = TheEndBiomeData.getEndBiomesMap().get(vanillaKey);
			replacementKey = picker.pickFromNoise(sampler, biomeX / 64.0, 0, biomeZ / 64.0);
		}

		return replacementKey;
	}
}
