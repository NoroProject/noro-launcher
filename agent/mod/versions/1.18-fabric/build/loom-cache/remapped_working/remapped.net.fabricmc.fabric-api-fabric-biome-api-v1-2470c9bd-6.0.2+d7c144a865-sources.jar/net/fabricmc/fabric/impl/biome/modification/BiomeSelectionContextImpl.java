/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.biome.modification;

import java.util.Optional;

import org.jetbrains.annotations.ApiStatus;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.StructureSettings;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.ConfiguredStructureFeature;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.storage.PrimaryLevelData;

@ApiStatus.Internal
public class BiomeSelectionContextImpl implements BiomeSelectionContext {
	private final RegistryAccess dynamicRegistries;
	private final PrimaryLevelData levelProperties;
	private final ResourceKey<Biome> key;
	private final Biome biome;

	public BiomeSelectionContextImpl(RegistryAccess dynamicRegistries, PrimaryLevelData levelProperties, ResourceKey<Biome> key, Biome biome) {
		this.dynamicRegistries = dynamicRegistries;
		this.levelProperties = levelProperties;
		this.key = key;
		this.biome = biome;
	}

	@Override
	public ResourceKey<Biome> getBiomeKey() {
		return key;
	}

	@Override
	public Biome getBiome() {
		return biome;
	}

	@Override
	public Optional<ResourceKey<ConfiguredFeature<?, ?>>> getFeatureKey(ConfiguredFeature<?, ?> configuredFeature) {
		Registry<ConfiguredFeature<?, ?>> registry = dynamicRegistries.registryOrThrow(Registry.CONFIGURED_FEATURE_REGISTRY);
		return registry.getResourceKey(configuredFeature);
	}

	@Override
	public Optional<ResourceKey<PlacedFeature>> getPlacedFeatureKey(PlacedFeature placedFeature) {
		Registry<PlacedFeature> registry = dynamicRegistries.registryOrThrow(Registry.PLACED_FEATURE_REGISTRY);
		return registry.getResourceKey(placedFeature);
	}

	@Override
	public boolean hasStructure(ResourceKey<ConfiguredStructureFeature<?, ?>> key) {
		ConfiguredStructureFeature<?, ?> instance = dynamicRegistries.registryOrThrow(Registry.CONFIGURED_STRUCTURE_FEATURE_REGISTRY).get(key);

		if (instance == null) {
			return false;
		}

		// Since the biome->structure mapping is now stored in the chunk generator configuration, we check every
		// chunk generator used by the current world-save.
		for (LevelStem dimension : levelProperties.worldGenSettings().dimensions()) {
			StructureSettings structuresConfig = dimension.generator().getSettings();

			if (structuresConfig.structures(instance.feature).get(instance).contains(getBiomeKey())) {
				return true;
			}
		}

		return false;
	}

	@Override
	public Optional<ResourceKey<ConfiguredStructureFeature<?, ?>>> getStructureKey(ConfiguredStructureFeature<?, ?> configuredStructure) {
		Registry<ConfiguredStructureFeature<?, ?>> registry = dynamicRegistries.registryOrThrow(Registry.CONFIGURED_STRUCTURE_FEATURE_REGISTRY);
		return registry.getResourceKey(configuredStructure);
	}

	@Override
	public boolean canGenerateIn(ResourceKey<LevelStem> dimensionKey) {
		LevelStem dimension = levelProperties.worldGenSettings().dimensions().get(dimensionKey);

		if (dimension == null) {
			return false;
		}

		return dimension.generator().getBiomeSource().possibleBiomes().contains(biome);
	}
}
