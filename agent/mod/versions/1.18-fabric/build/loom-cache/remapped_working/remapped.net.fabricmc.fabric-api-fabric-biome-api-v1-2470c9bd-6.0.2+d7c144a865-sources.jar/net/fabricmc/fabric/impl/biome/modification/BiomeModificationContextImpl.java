/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.biome.modification;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.function.Supplier;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.Music;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.random.WeightedRandomList;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.AmbientAdditionsSettings;
import net.minecraft.world.level.biome.AmbientMoodSettings;
import net.minecraft.world.level.biome.AmbientParticleSettings;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.carver.ConfiguredWorldCarver;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.ConfiguredStructureFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

@ApiStatus.Internal
public class BiomeModificationContextImpl implements BiomeModificationContext {
	private final RegistryAccess registries;
	private final ResourceKey<Biome> biomeKey;
	private final Biome biome;
	private final WeatherContext weather;
	private final EffectsContext effects;
	private final GenerationSettingsContextImpl generationSettings;
	private final SpawnSettingsContextImpl spawnSettings;

	public BiomeModificationContextImpl(RegistryAccess registries, ResourceKey<Biome> biomeKey, Biome biome) {
		this.registries = registries;
		this.biomeKey = biomeKey;
		this.biome = biome;
		this.weather = new WeatherContextImpl();
		this.effects = new EffectsContextImpl();
		this.generationSettings = new GenerationSettingsContextImpl();
		this.spawnSettings = new SpawnSettingsContextImpl();
	}

	@Override
	public void setCategory(Biome.BiomeCategory category) {
		biome.biomeCategory = category;
	}

	@Override
	public WeatherContext getWeather() {
		return weather;
	}

	@Override
	public EffectsContext getEffects() {
		return effects;
	}

	@Override
	public GenerationSettingsContext getGenerationSettings() {
		return generationSettings;
	}

	@Override
	public SpawnSettingsContext getSpawnSettings() {
		return spawnSettings;
	}

	/**
	 * Re-freeze any immutable lists and perform general post-modification cleanup.
	 */
	void freeze() {
		generationSettings.freeze();
		spawnSettings.freeze();
	}

	private class WeatherContextImpl implements WeatherContext {
		private final Biome.ClimateSettings weather = biome.climateSettings;

		@Override
		public void setPrecipitation(Biome.Precipitation precipitation) {
			weather.precipitation = Objects.requireNonNull(precipitation);
		}

		@Override
		public void setTemperature(float temperature) {
			weather.temperature = temperature;
		}

		@Override
		public void setTemperatureModifier(Biome.TemperatureModifier temperatureModifier) {
			weather.temperatureModifier = Objects.requireNonNull(temperatureModifier);
		}

		@Override
		public void setDownfall(float downfall) {
			weather.downfall = downfall;
		}
	}

	private class EffectsContextImpl implements EffectsContext {
		private final BiomeSpecialEffects effects = biome.getSpecialEffects();

		@Override
		public void setFogColor(int color) {
			effects.fogColor = color;
		}

		@Override
		public void setWaterColor(int color) {
			effects.waterColor = color;
		}

		@Override
		public void setWaterFogColor(int color) {
			effects.waterFogColor = color;
		}

		@Override
		public void setSkyColor(int color) {
			effects.skyColor = color;
		}

		@Override
		public void setFoliageColor(Optional<Integer> color) {
			effects.foliageColorOverride = Objects.requireNonNull(color);
		}

		@Override
		public void setGrassColor(Optional<Integer> color) {
			effects.grassColorOverride = Objects.requireNonNull(color);
		}

		@Override
		public void setGrassColorModifier(@NotNull BiomeSpecialEffects.GrassColorModifier colorModifier) {
			effects.grassColorModifier = Objects.requireNonNull(colorModifier);
		}

		@Override
		public void setParticleConfig(Optional<AmbientParticleSettings> particleConfig) {
			effects.ambientParticleSettings = Objects.requireNonNull(particleConfig);
		}

		@Override
		public void setAmbientSound(Optional<SoundEvent> sound) {
			effects.ambientLoopSoundEvent = Objects.requireNonNull(sound);
		}

		@Override
		public void setMoodSound(Optional<AmbientMoodSettings> sound) {
			effects.ambientMoodSettings = Objects.requireNonNull(sound);
		}

		@Override
		public void setAdditionsSound(Optional<AmbientAdditionsSettings> sound) {
			effects.ambientAdditionsSettings = Objects.requireNonNull(sound);
		}

		@Override
		public void setMusic(Optional<Music> sound) {
			effects.backgroundMusic = Objects.requireNonNull(sound);
		}
	}

	private class GenerationSettingsContextImpl implements GenerationSettingsContext {
		private final Registry<ConfiguredWorldCarver<?>> carvers = registries.registryOrThrow(Registry.CONFIGURED_CARVER_REGISTRY);
		private final Registry<PlacedFeature> features = registries.registryOrThrow(Registry.PLACED_FEATURE_REGISTRY);
		private final Registry<ConfiguredStructureFeature<?, ?>> structures = registries.registryOrThrow(Registry.CONFIGURED_STRUCTURE_FEATURE_REGISTRY);
		private final BiomeGenerationSettings generationSettings = biome.getGenerationSettings();

		/**
		 * Unfreeze the immutable lists found in the generation settings, and make sure they're filled up to every
		 * possible step if they're dense lists.
		 */
		GenerationSettingsContextImpl() {
			unfreezeCarvers();
			unfreezeFeatures();
			unfreezeFlowerFeatures();
		}

		private void unfreezeCarvers() {
			Map<GenerationStep.Carving, List<Supplier<ConfiguredWorldCarver<?>>>> carversByStep = new EnumMap<>(GenerationStep.Carving.class);
			carversByStep.putAll(generationSettings.carvers);

			for (GenerationStep.Carving step : GenerationStep.Carving.values()) {
				List<Supplier<ConfiguredWorldCarver<?>>> carvers = carversByStep.get(step);

				if (carvers == null) {
					carvers = new ArrayList<>();
				} else {
					carvers = new ArrayList<>(carvers);
				}

				carversByStep.put(step, carvers);
			}

			generationSettings.carvers = carversByStep;
		}

		private void unfreezeFeatures() {
			List<List<Supplier<PlacedFeature>>> features = generationSettings.features;
			features = new ArrayList<>(features);

			for (int i = 0; i < features.size(); i++) {
				features.set(i, new ArrayList<>(features.get(i)));
			}

			generationSettings.features = features;
			generationSettings.featureSet = new HashSet<>(generationSettings.featureSet);
		}

		private void unfreezeFlowerFeatures() {
			generationSettings.flowerFeatures = new ArrayList<>(generationSettings.flowerFeatures);
		}

		/**
		 * Re-freeze the lists in the generation settings to immutable variants, also fixes the flower features.
		 */
		public void freeze() {
			freezeCarvers();
			freezeFeatures();
			freezeFlowerFeatures();
		}

		private void freezeCarvers() {
			Map<GenerationStep.Carving, List<Supplier<ConfiguredWorldCarver<?>>>> carversByStep = generationSettings.carvers;

			for (GenerationStep.Carving step : GenerationStep.Carving.values()) {
				carversByStep.put(step, ImmutableList.copyOf(carversByStep.get(step)));
			}

			generationSettings.carvers = ImmutableMap.copyOf(carversByStep);
		}

		private void freezeFeatures() {
			List<List<Supplier<PlacedFeature>>> featureSteps = generationSettings.features;

			for (int i = 0; i < featureSteps.size(); i++) {
				featureSteps.set(i, ImmutableList.copyOf(featureSteps.get(i)));
			}

			generationSettings.features = ImmutableList.copyOf(featureSteps);
			generationSettings.featureSet = (Set.copyOf(generationSettings.featureSet));
		}

		private void freezeFlowerFeatures() {
			generationSettings.flowerFeatures = ImmutableList.copyOf(generationSettings.flowerFeatures);
		}

		@Override
		public boolean removeFeature(GenerationStep.Decoration step, ResourceKey<PlacedFeature> placedFeatureKey) {
			PlacedFeature configuredFeature = features.getOrThrow(placedFeatureKey);

			int stepIndex = step.ordinal();
			List<List<Supplier<PlacedFeature>>> featureSteps = generationSettings.features;

			if (stepIndex >= featureSteps.size()) {
				return false; // The step was not populated with any features yet
			}

			List<Supplier<PlacedFeature>> featuresInStep = featureSteps.get(stepIndex);

			if (featuresInStep.removeIf(supplier -> supplier.get() == configuredFeature)) {
				rebuildFlowerFeatures();
				return true;
			}

			return false;
		}

		@Override
		public void addFeature(GenerationStep.Decoration step, ResourceKey<PlacedFeature> placedFeatureKey) {
			// We do not need to delay evaluation of this since the registries are already fully built
			PlacedFeature placedFeature = features.getOrThrow(placedFeatureKey);

			List<List<Supplier<PlacedFeature>>> featureSteps = generationSettings.features;
			int index = step.ordinal();

			// Add new empty lists for the generation steps that have no features yet
			while (index >= featureSteps.size()) {
				featureSteps.add(new ArrayList<>());
			}

			featureSteps.get(index).add(() -> placedFeature);
			generationSettings.featureSet.add(placedFeature);

			// Ensure the list of flower features is up to date
			rebuildFlowerFeatures();
		}

		@Override
		public void addCarver(GenerationStep.Carving step, ResourceKey<ConfiguredWorldCarver<?>> carverKey) {
			// We do not need to delay evaluation of this since the registries are already fully built
			ConfiguredWorldCarver<?> carver = carvers.getOrThrow(carverKey);
			generationSettings.carvers.get(step).add(() -> carver);
		}

		@Override
		public boolean removeCarver(GenerationStep.Carving step, ResourceKey<ConfiguredWorldCarver<?>> configuredCarverKey) {
			ConfiguredWorldCarver<?> carver = carvers.getOrThrow(configuredCarverKey);
			return generationSettings.carvers.get(step).removeIf(supplier -> supplier.get() == carver);
		}

		@Override
		public void addStructure(ResourceKey<ConfiguredStructureFeature<?, ?>> configuredStructureKey) {
			ConfiguredStructureFeature<?, ?> configuredStructure = structures.getOrThrow(configuredStructureKey);

			BiomeStructureStartsImpl.addStart(registries, configuredStructure, biomeKey);
		}

		@Override
		public boolean removeStructure(ResourceKey<ConfiguredStructureFeature<?, ?>> configuredStructureKey) {
			ConfiguredStructureFeature<?, ?> configuredStructure = structures.getOrThrow(configuredStructureKey);

			return BiomeStructureStartsImpl.removeStart(registries, configuredStructure, biomeKey);
		}

		@Override
		public boolean removeStructure(StructureFeature<?> structure) {
			return BiomeStructureStartsImpl.removeStructureStarts(registries, structure, biomeKey);
		}

		/**
		 * See the constructor of {@link BiomeGenerationSettings} for reference.
		 */
		private void rebuildFlowerFeatures() {
			List<ConfiguredFeature<?, ?>> flowerFeatures = generationSettings.flowerFeatures;
			flowerFeatures.clear();

			for (List<Supplier<PlacedFeature>> features : generationSettings.features) {
				for (Supplier<PlacedFeature> supplier : features) {
					supplier.get().getFeatures()
							.filter(configuredFeature -> configuredFeature.feature == Feature.FLOWER)
							.forEachOrdered(flowerFeatures::add);
				}
			}
		}
	}

	private class SpawnSettingsContextImpl implements SpawnSettingsContext {
		private final MobSpawnSettings spawnSettings = biome.getMobSettings();
		private final EnumMap<MobCategory, List<MobSpawnSettings.SpawnerData>> fabricSpawners = new EnumMap<>(MobCategory.class);

		SpawnSettingsContextImpl() {
			unfreezeSpawners();
			unfreezeSpawnCost();
		}

		private void unfreezeSpawners() {
			fabricSpawners.clear();

			for (MobCategory spawnGroup : MobCategory.values()) {
				WeightedRandomList<MobSpawnSettings.SpawnerData> entries = spawnSettings.spawners.get(spawnGroup);

				if (entries != null) {
					fabricSpawners.put(spawnGroup, new ArrayList<>(entries.unwrap()));
				} else {
					fabricSpawners.put(spawnGroup, new ArrayList<>());
				}
			}
		}

		private void unfreezeSpawnCost() {
			spawnSettings.mobSpawnCosts = new HashMap<>(spawnSettings.mobSpawnCosts);
		}

		public void freeze() {
			freezeSpawners();
			freezeSpawnCosts();
		}

		private void freezeSpawners() {
			Map<MobCategory, WeightedRandomList<MobSpawnSettings.SpawnerData>> spawners = new HashMap<>(spawnSettings.spawners);

			for (Map.Entry<MobCategory, List<MobSpawnSettings.SpawnerData>> entry : fabricSpawners.entrySet()) {
				if (entry.getValue().isEmpty()) {
					spawners.put(entry.getKey(), WeightedRandomList.create());
				} else {
					spawners.put(entry.getKey(), WeightedRandomList.create(entry.getValue()));
				}
			}

			spawnSettings.spawners = ImmutableMap.copyOf(spawners);
		}

		private void freezeSpawnCosts() {
			spawnSettings.mobSpawnCosts = ImmutableMap.copyOf(spawnSettings.mobSpawnCosts);
		}

		@Override
		public void setCreatureSpawnProbability(float probability) {
			spawnSettings.creatureGenerationProbability = probability;
		}

		@Override
		public void addSpawn(MobCategory spawnGroup, MobSpawnSettings.SpawnerData spawnEntry) {
			Objects.requireNonNull(spawnGroup);
			Objects.requireNonNull(spawnEntry);

			fabricSpawners.get(spawnGroup).add(spawnEntry);
		}

		@Override
		public boolean removeSpawns(BiPredicate<MobCategory, MobSpawnSettings.SpawnerData> predicate) {
			boolean anyRemoved = false;

			for (MobCategory group : MobCategory.values()) {
				if (fabricSpawners.get(group).removeIf(entry -> predicate.test(group, entry))) {
					anyRemoved = true;
				}
			}

			return anyRemoved;
		}

		@Override
		public void setSpawnCost(EntityType<?> entityType, double mass, double gravityLimit) {
			Objects.requireNonNull(entityType);
			spawnSettings.mobSpawnCosts.put(entityType, new MobSpawnSettings.MobSpawnCost(gravityLimit, mass));
		}

		@Override
		public void clearSpawnCost(EntityType<?> entityType) {
			spawnSettings.mobSpawnCosts.remove(entityType);
		}
	}
}
