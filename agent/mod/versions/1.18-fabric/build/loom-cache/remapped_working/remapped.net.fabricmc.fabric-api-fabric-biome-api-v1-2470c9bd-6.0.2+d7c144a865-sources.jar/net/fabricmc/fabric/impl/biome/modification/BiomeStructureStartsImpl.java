/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.biome.modification;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.data.BuiltinRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.levelgen.feature.ConfiguredStructureFeature;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import org.jetbrains.annotations.ApiStatus;

/**
 * Helps with modifying the structure start information stored in {@link NoiseGeneratorSettings}.
 */
@ApiStatus.Internal
public final class BiomeStructureStartsImpl {
	private BiomeStructureStartsImpl() {
	}

	public static void addStart(
			RegistryAccess registries,
			ConfiguredStructureFeature<?, ?> configuredStructure,
			ResourceKey<Biome> biome
	) {
		changeStructureStarts(registries, structureMap -> {
			Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>> configuredMap = structureMap.computeIfAbsent(configuredStructure.feature, k -> HashMultimap.create());

			// This is tricky, the keys might be either from builtin (Vanilla) or dynamic registries (modded)
			ResourceKey<ConfiguredStructureFeature<?, ?>> configuredStructureKey = registries.registryOrThrow(Registry.CONFIGURED_STRUCTURE_FEATURE_REGISTRY).getResourceKey(configuredStructure).orElseThrow();
			ConfiguredStructureFeature<?, ?> mapKey = BuiltinRegistries.CONFIGURED_STRUCTURE_FEATURE.get(configuredStructureKey);

			if (mapKey == null) {
				// This means the configured structure passed in is not a (potentially modified) Vanilla entry,
				// but rather a modded one. In this case, this will create a new entry in the map.
				mapKey = configuredStructure;
			}

			configuredMap.put(mapKey, biome);
		});
	}

	public static boolean removeStart(
			RegistryAccess registries,
			ConfiguredStructureFeature<?, ?> configuredStructure,
			ResourceKey<Biome> biome
	) {
		AtomicBoolean result = new AtomicBoolean(false);

		changeStructureStarts(registries, structureMap -> {
			Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>> configuredMap = structureMap.get(configuredStructure.feature);

			if (configuredMap == null) {
				return;
			}

			// This is tricky, the keys might be either from builtin (Vanilla) or dynamic registries (modded)
			ResourceKey<ConfiguredStructureFeature<?, ?>> configuredStructureKey = registries.registryOrThrow(Registry.CONFIGURED_STRUCTURE_FEATURE_REGISTRY).getResourceKey(configuredStructure).orElseThrow();
			ConfiguredStructureFeature<?, ?> mapKey = BuiltinRegistries.CONFIGURED_STRUCTURE_FEATURE.get(configuredStructureKey);

			if (mapKey == null) {
				// This means the configured structure passed in is not a (potentially modified) Vanilla entry,
				// but rather a modded one. In this case, this will create a new entry in the map.
				mapKey = configuredStructure;
			}

			if (configuredMap.remove(mapKey, biome)) {
				result.set(true);
			}
		});

		return result.get();
	}

	public static boolean removeStructureStarts(
			RegistryAccess registries,
			StructureFeature<?> structure,
			ResourceKey<Biome> biome
	) {
		AtomicBoolean result = new AtomicBoolean(false);

		changeStructureStarts(registries, structureMap -> {
			Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>> configuredMap = structureMap.get(structure);

			if (configuredMap == null) {
				return;
			}

			if (configuredMap.values().remove(biome)) {
				result.set(true);
			}
		});

		return result.get();
	}

	private static void changeStructureStarts(RegistryAccess registries, Consumer<Map<StructureFeature<?>, Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>>>> modifier) {
		Registry<NoiseGeneratorSettings> chunkGenSettingsRegistry = registries.registryOrThrow(Registry.NOISE_GENERATOR_SETTINGS_REGISTRY);

		for (Map.Entry<ResourceKey<NoiseGeneratorSettings>, NoiseGeneratorSettings> entry : chunkGenSettingsRegistry.entrySet()) {
			Map<StructureFeature<?>, Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>>> structureMap = unfreeze(entry.getValue());

			modifier.accept(structureMap);

			freeze(entry.getValue(), structureMap);
		}
	}

	private static Map<StructureFeature<?>, Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>>> unfreeze(NoiseGeneratorSettings settings) {
		ImmutableMap<StructureFeature<?>, ImmutableMultimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>>> frozenMap = settings.structureSettings().configuredStructures;
		Map<StructureFeature<?>, Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>>> result = new HashMap<>(frozenMap.size());

		for (Map.Entry<StructureFeature<?>, ImmutableMultimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>>> entry : frozenMap.entrySet()) {
			result.put(entry.getKey(), HashMultimap.create(entry.getValue()));
		}

		return result;
	}

	private static void freeze(NoiseGeneratorSettings settings, Map<StructureFeature<?>, Multimap<ConfiguredStructureFeature<?, ?>, ResourceKey<Biome>>> structureStarts) {
		settings.structureSettings().configuredStructures = structureStarts.entrySet().stream()
				.collect(ImmutableMap.toImmutableMap(
						Map.Entry::getKey,
						e -> ImmutableMultimap.copyOf(e.getValue())
				));
	}
}
