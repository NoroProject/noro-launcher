/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.datagen;

import java.util.function.Predicate;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.StaticTags;
import net.minecraft.tags.Tag;
import net.minecraft.tags.TagCollection;
import net.minecraft.tags.TagContainer;

public class FabricTagEntry<T> extends Tag.TagEntry {
	private static final TagContainer TAG_MANAGER = StaticTags.createCollection();

	private final Registry<T> registry;
	private final ResourceLocation id;
	private final boolean allowNonVanilla;

	public FabricTagEntry(Registry<T> registry, ResourceLocation id, boolean allowNonVanilla) {
		super(id);

		this.registry = registry;
		this.id = id;
		this.allowNonVanilla = allowNonVanilla;
	}

	@Override
	public boolean verifyIfPresent(Predicate<ResourceLocation> existenceTest, Predicate<ResourceLocation> duplicationTest) {
		if (allowNonVanilla) {
			return true;
		}

		TagCollection<T> tagGroup = TAG_MANAGER.getOrEmpty(registry.key());
		return tagGroup.hasTag(id) || super.verifyIfPresent(existenceTest, duplicationTest);
	}
}
