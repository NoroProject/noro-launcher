/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.block;

import net.fabricmc.fabric.impl.object.builder.FabricBlockInternals;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockSettingsAccessor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.Tag;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.MaterialColor;

/**
 * @deprecated Please migrate to v1. Please use methods in {@link net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings} instead.
 */
@Deprecated
public final class BlockSettingsExtensions {
	private BlockSettingsExtensions() {
	}

	public static void breakByHand(Properties settings, boolean breakByHand) {
		FabricBlockInternals.computeExtraData(settings).breakByHand(breakByHand);
	}

	public static void breakByTool(Properties settings, Tag<Item> tag, int miningLevel) {
		FabricBlockInternals.computeExtraData(settings).addMiningLevel(tag, miningLevel);
	}

	public static void hardness(Properties settings, float hardness) {
		((AbstractBlockSettingsAccessor) settings).setHardness(hardness);
	}

	public static void resistance(Properties settings, float resistance) {
		((AbstractBlockSettingsAccessor) settings).setResistance(Math.max(0.0F, resistance));
	}

	public static void collidable(Properties settings, boolean collidable) {
		((AbstractBlockSettingsAccessor) settings).setCollidable(collidable);
	}

	public static void materialColor(Properties settings, MaterialColor color) {
		((AbstractBlockSettingsAccessor) settings).setMapColorProvider(ignored -> color);
	}

	public static void drops(Properties settings, ResourceLocation dropTableId) {
		((AbstractBlockSettingsAccessor) settings).setLootTableId(dropTableId);
	}

	public static void sounds(Properties settings, SoundType soundGroup) {
		((AbstractBlockSettingsAccessor) settings).invokeSounds(soundGroup);
	}

	public static void lightLevel(Properties settings, int lightLevel) {
		((AbstractBlockSettingsAccessor) settings).setLuminanceFunction(ignored -> lightLevel);
	}

	public static void breakInstantly(Properties settings) {
		((AbstractBlockSettingsAccessor) settings).invokeBreakInstantly();
	}

	public static void strength(Properties settings, float strength) {
		((AbstractBlockSettingsAccessor) settings).invokeStrength(strength);
	}

	public static void ticksRandomly(Properties settings) {
		((AbstractBlockSettingsAccessor) settings).invokeTicksRandomly();
	}

	public static void dynamicBounds(Properties settings) {
		// Thanks Mixin
		((AbstractBlockSettingsAccessor) settings).setDynamicBounds(true);
	}

	public static void dropsNothing(Properties settings) {
		((AbstractBlockSettingsAccessor) settings).invokeDropsNothing();
	}
}
