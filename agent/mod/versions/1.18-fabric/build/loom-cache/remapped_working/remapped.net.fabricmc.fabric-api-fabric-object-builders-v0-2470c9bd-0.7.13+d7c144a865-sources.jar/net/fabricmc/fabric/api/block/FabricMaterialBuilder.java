/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.block;

import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;
import net.minecraft.world.level.material.PushReaction;

/**
 * @deprecated Please migrate to v1. Please use {@link net.fabricmc.fabric.api.object.builder.v1.block.FabricMaterialBuilder} instead.
 */
@Deprecated
public class FabricMaterialBuilder extends Material.Builder {
	private net.fabricmc.fabric.api.object.builder.v1.block.FabricMaterialBuilder delegate;

	public FabricMaterialBuilder(MaterialColor color) {
		super(color);
		this.delegate = new net.fabricmc.fabric.api.object.builder.v1.block.FabricMaterialBuilder(color);
	}

	public FabricMaterialBuilder(DyeColor color) {
		this(color.getMaterialColor());
	}

	@Override
	public FabricMaterialBuilder flammable() {
		this.delegate.flammable();
		return this;
	}

	public FabricMaterialBuilder pistonBehavior(PushReaction behavior) {
		this.delegate.pistonBehavior(behavior);
		return this;
	}

	public FabricMaterialBuilder notSolidBlocking() {
		this.delegate.notSolidBlocking();
		return this;
	}

	@Override
	public FabricMaterialBuilder destroyOnPush() {
		this.delegate.destroyOnPush();
		return this;
	}

	@Override
	public FabricMaterialBuilder notPushable() {
		this.delegate.notPushable();
		return this;
	}

	@Override
	public FabricMaterialBuilder noCollider() {
		this.delegate.noCollider();
		return this;
	}

	@Override
	public FabricMaterialBuilder liquid() {
		this.delegate.liquid();
		return this;
	}

	@Override
	public FabricMaterialBuilder nonSolid() {
		this.delegate.nonSolid();
		return this;
	}

	@Override
	public FabricMaterialBuilder replaceable() {
		this.delegate.replaceable();
		return this;
	}

	@Override
	public Material build() {
		return this.delegate.build();
	}
}
