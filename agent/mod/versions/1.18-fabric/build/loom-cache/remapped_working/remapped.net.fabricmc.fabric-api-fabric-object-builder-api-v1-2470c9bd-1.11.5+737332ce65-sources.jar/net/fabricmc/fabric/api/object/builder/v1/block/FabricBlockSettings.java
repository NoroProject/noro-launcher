/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.object.builder.v1.block;

import java.util.function.ToIntFunction;
import net.fabricmc.fabric.impl.object.builder.BlockSettingsInternals;
import net.fabricmc.fabric.impl.object.builder.FabricBlockInternals;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockAccessor;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockSettingsAccessor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.Tag;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;

/**
 * Fabric's version of Block.Settings. Adds additional methods and hooks
 * not found in the original class.
 *
 * <p>To use it, simply replace Block.Settings.of() with
 * FabricBlockSettings.of().
 */
public class FabricBlockSettings extends BlockBehaviour.Properties {
	protected FabricBlockSettings(Material material, MaterialColor color) {
		super(material, color);
	}

	protected FabricBlockSettings(BlockBehaviour.Properties settings) {
		super(((AbstractBlockSettingsAccessor) settings).getMaterial(), ((AbstractBlockSettingsAccessor) settings).getMapColorProvider());
		// Mostly Copied from vanilla's copy method
		// Note: If new methods are added to Block settings, an accessor must be added here
		AbstractBlockSettingsAccessor thisAccessor = (AbstractBlockSettingsAccessor) this;
		AbstractBlockSettingsAccessor otherAccessor = (AbstractBlockSettingsAccessor) settings;

		thisAccessor.setMaterial(otherAccessor.getMaterial());
		this.method_36557(otherAccessor.getHardness());
		this.method_36558(otherAccessor.getResistance());
		this.collidable(otherAccessor.getCollidable());
		thisAccessor.setRandomTicks(otherAccessor.getRandomTicks());
		this.method_9631(otherAccessor.getLuminance());
		thisAccessor.setMapColorProvider(otherAccessor.getMapColorProvider());
		this.method_9626(otherAccessor.getSoundGroup());
		this.method_9628(otherAccessor.getSlipperiness());
		this.method_23351(otherAccessor.getVelocityMultiplier());
		thisAccessor.setDynamicBounds(otherAccessor.getDynamicBounds());
		thisAccessor.setOpaque(otherAccessor.getOpaque());
		thisAccessor.setIsAir(otherAccessor.getIsAir());
		thisAccessor.setToolRequired(otherAccessor.isToolRequired());

		// Now attempt to copy fabric specific data
		BlockSettingsInternals otherInternals = (BlockSettingsInternals) settings;
		FabricBlockInternals.ExtraData extraData = otherInternals.getExtraData();

		if (extraData != null) { // If present, populate the extra data on our new settings
			((BlockSettingsInternals) this).setExtraData(extraData);
		}
	}

	public static FabricBlockSettings method_9637(Material material) {
		return method_9639(material, material.getColor());
	}

	public static FabricBlockSettings method_9639(Material material, MaterialColor color) {
		return new FabricBlockSettings(material, color);
	}

	public static FabricBlockSettings method_9617(Material material, DyeColor color) {
		return new FabricBlockSettings(material, color.getMaterialColor());
	}

	public static FabricBlockSettings copyOf(BlockBehaviour block) {
		return new FabricBlockSettings(((AbstractBlockAccessor) block).getSettings());
	}

	public static FabricBlockSettings copyOf(BlockBehaviour.Properties settings) {
		return new FabricBlockSettings(settings);
	}

	@Override
	public FabricBlockSettings method_9634() {
		super.noCollission();
		return this;
	}

	@Override
	public FabricBlockSettings method_22488() {
		super.noOcclusion();
		return this;
	}

	@Override
	public FabricBlockSettings method_9628(float value) {
		super.friction(value);
		return this;
	}

	@Override
	public FabricBlockSettings method_23351(float velocityMultiplier) {
		super.speedFactor(velocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings method_23352(float jumpVelocityMultiplier) {
		super.jumpFactor(jumpVelocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings method_9626(SoundType group) {
		super.sound(group);
		return this;
	}

	/**
	 * @deprecated Please use {@link FabricBlockSettings#method_9631(ToIntFunction)}.
	 */
	public FabricBlockSettings lightLevel(ToIntFunction<BlockState> levelFunction) {
		return this.method_9631(levelFunction);
	}

	@Override
	public FabricBlockSettings method_9631(ToIntFunction<BlockState> luminanceFunction) {
		super.lightLevel(luminanceFunction);
		return this;
	}

	@Override
	public FabricBlockSettings method_9629(float hardness, float resistance) {
		super.strength(hardness, resistance);
		return this;
	}

	@Override
	public FabricBlockSettings method_9618() {
		super.instabreak();
		return this;
	}

	public FabricBlockSettings method_9632(float strength) {
		super.strength(strength);
		return this;
	}

	@Override
	public FabricBlockSettings method_9640() {
		super.randomTicks();
		return this;
	}

	@Override
	public FabricBlockSettings method_9624() {
		super.dynamicShape();
		return this;
	}

	@Override
	public FabricBlockSettings method_16229() {
		super.noDrops();
		return this;
	}

	@Override
	public FabricBlockSettings method_16228(Block block) {
		super.dropsLike(block);
		return this;
	}

	@Override
	public FabricBlockSettings method_26250() {
		super.air();
		return this;
	}

	@Override
	public FabricBlockSettings method_26235(BlockBehaviour.StateArgumentPredicate<EntityType<?>> predicate) {
		super.isValidSpawn(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26236(BlockBehaviour.StatePredicate predicate) {
		super.isRedstoneConductor(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26243(BlockBehaviour.StatePredicate predicate) {
		super.isSuffocating(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26245(BlockBehaviour.StatePredicate predicate) {
		super.isViewBlocking(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26247(BlockBehaviour.StatePredicate predicate) {
		super.hasPostProcess(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26249(BlockBehaviour.StatePredicate predicate) {
		super.emissiveRendering(predicate);
		return this;
	}

	/* FABRIC ADDITIONS*/

	/**
	 * @deprecated Please use {@link FabricBlockSettings#luminance(int)}.
	 */
	@Deprecated
	public FabricBlockSettings lightLevel(int lightLevel) {
		this.luminance(lightLevel);
		return this;
	}

	public FabricBlockSettings luminance(int luminance) {
		this.method_9631(ignored -> luminance);
		return this;
	}

	public FabricBlockSettings method_36557(float hardness) {
		((AbstractBlockSettingsAccessor) this).setHardness(hardness);
		return this;
	}

	public FabricBlockSettings method_36558(float resistance) {
		((AbstractBlockSettingsAccessor) this).setResistance(Math.max(0.0F, resistance));
		return this;
	}

	public FabricBlockSettings drops(ResourceLocation dropTableId) {
		((AbstractBlockSettingsAccessor) this).setLootTableId(dropTableId);
		return this;
	}

	/**
	 * Make the block require tool to drop and slows down mining speed if the incorrect tool is used.
	 */
	@Override
	public FabricBlockSettings method_29292() {
		super.requiresCorrectToolForDrops();
		return this;
	}

	/* FABRIC DELEGATE WRAPPERS */

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#method_31710(MaterialColor)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(MaterialColor color) {
		return this.method_31710(color);
	}

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#mapColor(DyeColor)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(DyeColor color) {
		return this.mapColor(color);
	}

	public FabricBlockSettings method_31710(MaterialColor color) {
		((AbstractBlockSettingsAccessor) this).setMapColorProvider(ignored -> color);
		return this;
	}

	public FabricBlockSettings mapColor(DyeColor color) {
		return this.method_31710(color.getMaterialColor());
	}

	public FabricBlockSettings collidable(boolean collidable) {
		((AbstractBlockSettingsAccessor) this).setCollidable(collidable);
		return this;
	}

	/* FABRIC HELPERS */

	/**
	 * Makes the block breakable by any tool if {@code breakByHand} is set to true.
	 */
	public FabricBlockSettings breakByHand(boolean breakByHand) {
		FabricBlockInternals.computeExtraData(this).breakByHand(breakByHand);
		return this;
	}

	/**
	 * Please make the block require a tool if you plan to disable drops and slow the breaking down using the
	 * incorrect tool by using {@link FabricBlockSettings#method_29292()}.
	 *
	 * @deprecated Replaced by {@code mineable} tags. See fabric-mining-level-api-v1 for further details.
	 */
	@Deprecated(forRemoval = true)
	public FabricBlockSettings breakByTool(Tag<Item> tag, int miningLevel) {
		FabricBlockInternals.computeExtraData(this).addMiningLevel(tag, miningLevel);
		return this;
	}

	/**
	 * Please make the block require a tool if you plan to disable drops and slow the breaking down using the
	 * incorrect tool by using {@link FabricBlockSettings#method_29292()}.
	 *
	 * @deprecated Replaced by {@code mineable} tags. See fabric-mining-level-api-v1 for further details.S
	 */
	@Deprecated(forRemoval = true)
	public FabricBlockSettings breakByTool(Tag<Item> tag) {
		return this.breakByTool(tag, 0);
	}
}
