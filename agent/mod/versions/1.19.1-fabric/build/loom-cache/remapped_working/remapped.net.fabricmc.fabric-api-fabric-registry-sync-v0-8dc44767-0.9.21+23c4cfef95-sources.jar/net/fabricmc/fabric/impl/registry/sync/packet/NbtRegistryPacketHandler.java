/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.registry.sync.packet;

import java.util.Map;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.impl.registry.sync.RegistryMapSerializer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

/**
 * A method to sync registry ids using {@link CompoundTag} and {@link FriendlyByteBuf#writeNbt}.
 * Kept here for old version support.
 */
// TODO: Remove
@Deprecated
public class NbtRegistryPacketHandler extends RegistryPacketHandler {
	private static final ResourceLocation ID = new ResourceLocation("fabric", "registry/sync");

	private Map<ResourceLocation, Object2IntMap<ResourceLocation>> syncedRegistryMap;

	@Override
	public ResourceLocation getPacketId() {
		return ID;
	}

	@Override
	public void sendPacket(ServerPlayer player, Map<ResourceLocation, Object2IntMap<ResourceLocation>> registryMap) {
		FriendlyByteBuf buf = PacketByteBufs.create();
		buf.writeNbt(RegistryMapSerializer.toNbt(registryMap));
		sendPacket(player, buf);
	}

	@Override
	public void receivePacket(FriendlyByteBuf buf) {
		computeBufSize(buf);
		CompoundTag nbt = buf.readNbt();
		syncedRegistryMap = nbt != null ? RegistryMapSerializer.fromNbt(nbt) : null;
	}

	@Override
	public int getTotalPacketReceived() {
		return 1;
	}

	@Override
	public boolean isPacketFinished() {
		return true;
	}

	@Override
	@Nullable
	public Map<ResourceLocation, Object2IntMap<ResourceLocation>> getSyncedRegistryMap() {
		return syncedRegistryMap;
	}
}
