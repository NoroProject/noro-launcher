/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.datagen.v1.provider;

import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import org.jetbrains.annotations.ApiStatus;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.resource.conditions.v1.ConditionJsonProvider;
import net.fabricmc.fabric.impl.datagen.FabricDataGenHelper;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.LootTables;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSet;

/**
 * A base interface for Loot table providers. You should not implement this class directly.
 *
 * <p>{@link FabricBlockLootTableProvider} provides additional features specific to block drop loot tables.
 *
 * <p>Use {@link SimpleFabricLootTableProvider} for a simple abstract class that you can implement to handle standard loot table functions.
 */
@ApiStatus.NonExtendable
public interface FabricLootTableProvider extends Consumer<BiConsumer<ResourceLocation, LootTable.Builder>>, DataProvider {
	LootContextParamSet getLootContextType();

	FabricDataGenerator getFabricDataGenerator();

	/**
	 * Return a new exporter that applies the specified conditions to any loot table it receives.
	 */
	default BiConsumer<ResourceLocation, LootTable.Builder> withConditions(BiConsumer<ResourceLocation, LootTable.Builder> exporter, ConditionJsonProvider... conditions) {
		Preconditions.checkArgument(conditions.length > 0, "Must add at least one condition.");
		return (id, table) -> {
			FabricDataGenHelper.addConditions(table, conditions);
			exporter.accept(id, table);
		};
	}

	@ApiStatus.Internal
	@Override
	default void run(CachedOutput writer) throws IOException {
		HashMap<ResourceLocation, LootTable> builders = Maps.newHashMap();
		HashMap<ResourceLocation, ConditionJsonProvider[]> conditionMap = new HashMap<>();

		accept((identifier, builder) -> {
			ConditionJsonProvider[] conditions = FabricDataGenHelper.consumeConditions(builder);
			conditionMap.put(identifier, conditions);

			if (builders.put(identifier, builder.setParamSet(getLootContextType()).build()) != null) {
				throw new IllegalStateException("Duplicate loot table " + identifier);
			}
		});

		for (Map.Entry<ResourceLocation, LootTable> entry : builders.entrySet()) {
			JsonObject tableJson = (JsonObject) LootTables.serialize(entry.getValue());
			ConditionJsonProvider.write(tableJson, conditionMap.remove(entry.getKey()));

			DataProvider.saveStable(writer, tableJson, getOutputPath(entry.getKey()));
		}
	}

	private Path getOutputPath(ResourceLocation lootTableId) {
		return getFabricDataGenerator().getOutputFolder().resolve("data/%s/loot_tables/%s.json".formatted(lootTableId.getNamespace(), lootTableId.getPath()));
	}
}
