/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.command.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientSuggestionProvider;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.ChatSender;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;

@Mixin(ClientSuggestionProvider.class)
abstract class ClientCommandSourceMixin implements FabricClientCommandSource {
	@Shadow
	@Final
	private Minecraft client;

	@Override
	public void sendFeedback(Component message) {
		client.gui.handlePlayerChat(getSystemMessageType(), message, new ChatSender(Util.NIL_UUID, message));
	}

	@Override
	public void sendError(Component message) {
		client.gui.handlePlayerChat(getSystemMessageType(), Component.literal("").append(message).withStyle(ChatFormatting.RED), new ChatSender(Util.NIL_UUID, message));
	}

	@Unique
	private ChatType getSystemMessageType() {
		Registry<ChatType> registry = client.level.registryAccess().registryOrThrow(Registry.CHAT_TYPE_REGISTRY);
		return registry.get(ChatType.SYSTEM);
	}

	@Override
	public Minecraft getClient() {
		return client;
	}

	@Override
	public LocalPlayer getPlayer() {
		return client.player;
	}

	@Override
	public ClientLevel getWorld() {
		return client.level;
	}
}
