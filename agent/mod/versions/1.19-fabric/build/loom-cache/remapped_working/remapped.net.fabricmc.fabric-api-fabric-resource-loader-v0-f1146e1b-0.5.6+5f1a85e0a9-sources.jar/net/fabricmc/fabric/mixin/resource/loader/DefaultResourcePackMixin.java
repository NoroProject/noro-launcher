/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.resource.loader;

import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.function.Predicate;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.FilePackResources;
import net.minecraft.server.packs.FolderPackResources;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.VanillaPackResources;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;

/**
 * Make the default resource pack use the MC jar directly instead of the full classpath.
 * This is a major speed improvement, as well as a bugfix (it prevents other mod jars from overriding MC's resources).
 */
@Mixin(VanillaPackResources.class)
public abstract class DefaultResourcePackMixin {
	/**
	 * Redirect all resource access to the MC jar zip pack.
	 */
	final PackResources fabric_mcJarPack = createJarZipPack();

	@Unique
	private PackResources createJarZipPack() {
		PackType type;

		if (getClass().equals(VanillaPackResources.class)) {
			// Server pack
			type = PackType.SERVER_DATA;
		} else {
			// Client pack
			type = PackType.CLIENT_RESOURCES;
		}

		// Locate MC jar by finding the URL that contains the assets root.
		try {
			URL assetsRootUrl = VanillaPackResources.class.getResource("/" + type.getDirectory() + "/.mcassetsroot");
			URLConnection connection = assetsRootUrl.openConnection();

			if (connection instanceof JarURLConnection jarURLConnection) {
				return new FilePackResources(Paths.get(jarURLConnection.getJarFileURL().toURI()).toFile());
			} else {
				// Not a jar, assume it's a regular directory.
				Path rootPath = Paths.get(assetsRootUrl.toURI()).resolve("../..").toAbsolutePath();
				return new FolderPackResources(rootPath.toFile());
			}
		} catch (Exception exception) {
			throw new RuntimeException("Fabric: Failed to locate Minecraft assets root!", exception);
		}
	}

	/**
	 * @author FabricMC
	 * @reason Gets rid of classpath scanning.
	 */
	@Overwrite
	public Collection<ResourceLocation> findResources(PackType type, String namespace, String prefix, Predicate<ResourceLocation> predicate) {
		return fabric_mcJarPack.getResources(type, namespace, prefix, predicate);
	}

	/**
	 * @author FabricMC
	 * @reason Gets rid of classpath scanning.
	 */
	@Overwrite
	public boolean contains(PackType type, ResourceLocation id) {
		return fabric_mcJarPack.hasResource(type, id);
	}

	/**
	 * @author FabricMC
	 * @reason Close the resource pack we redirect resource access to.
	 */
	@Overwrite
	public void close() {
		fabric_mcJarPack.close();
	}

	/**
	 * @author FabricMC
	 * @reason Gets rid of classpath scanning.
	 */
	@Nullable
	@Overwrite
	public InputStream getInputStream(String path) throws IOException {
		return fabric_mcJarPack.getRootResource(path);
	}

	/**
	 * @author FabricMC
	 * @reason Gets rid of classpath scanning.
	 */
	@Nullable
	@Overwrite
	public InputStream findInputStream(PackType type, ResourceLocation id) throws IOException {
		return fabric_mcJarPack.getResource(type, id);
	}
}
