/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.itemgroup;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.mixin.itemgroup.ItemGroupsAccessor;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;

public final class ItemGroupHelper {
	private ItemGroupHelper() {
	}

	/**
	 * A list of item groups, but with special groups grouped at the end.
	 */
	public static List<CreativeModeTab> sortedGroups = CreativeModeTabs.allTabs();

	public static void appendItemGroup(CreativeModeTab itemGroup) {
		for (CreativeModeTab existingGroup : CreativeModeTabs.allTabs()) {
			if (existingGroup.getId().equals(itemGroup.getId())) {
				throw new IllegalStateException("Duplicate item group: " + itemGroup.getId());
			}
		}

		var itemGroups = new ArrayList<>(CreativeModeTabs.allTabs());
		itemGroups.add(itemGroup);

		List<CreativeModeTab> validated = ItemGroupsAccessor.invokeCollect(itemGroups.toArray(CreativeModeTab[]::new));
		ItemGroupsAccessor.setGroups(validated);
		sortedGroups = validated.stream().sorted((a, b) -> {
			if (a.isAlignedRight() && !b.isAlignedRight()) return 1;
			if (!a.isAlignedRight() && b.isAlignedRight()) return -1;
			return 0;
		}).toList();
	}
}
