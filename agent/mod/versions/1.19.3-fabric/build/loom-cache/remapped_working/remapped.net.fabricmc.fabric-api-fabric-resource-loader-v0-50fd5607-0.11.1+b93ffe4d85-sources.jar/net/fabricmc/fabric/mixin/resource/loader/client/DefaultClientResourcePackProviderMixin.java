/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.resource.loader.client;

import java.util.ArrayList;
import java.util.List;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import net.fabricmc.fabric.api.resource.ModResourcePack;
import net.fabricmc.fabric.impl.client.resource.loader.ProgrammerArtResourcePack;
import net.fabricmc.fabric.impl.resource.loader.ModResourcePackUtil;
import net.minecraft.client.resources.ClientPackSource;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.AbstractPackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;

@Mixin(ClientPackSource.class)
public class DefaultClientResourcePackProviderMixin {
	/**
	 * Injects into the method which registers/creates the Programmer Art resource pack,
	 * and replaces the local {@link net.minecraft.server.packs.repository.Pack.ResourcesSupplier}
	 * instance with our custom Programmer Art wrapper that supports loading from mods.
	 */
	@ModifyArg(
			method = "create(Ljava/lang/String;Lnet/minecraft/resource/ResourcePackProfile$PackFactory;Lnet/minecraft/text/Text;)Lnet/minecraft/resource/ResourcePackProfile;",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/resource/ResourcePackProfile;create(Ljava/lang/String;Lnet/minecraft/text/Text;ZLnet/minecraft/resource/ResourcePackProfile$PackFactory;Lnet/minecraft/resource/ResourceType;Lnet/minecraft/resource/ResourcePackProfile$InsertionPosition;Lnet/minecraft/resource/ResourcePackSource;)Lnet/minecraft/resource/ResourcePackProfile;"
			),
			index = 3
	)
	private Pack.ResourcesSupplier onCreateProgrammerArtResourcePack(String name, Component displayName, boolean alwaysEnabled,
			Pack.ResourcesSupplier packFactory, PackType type, Pack.Position position, PackSource source) {
		return factory -> new ProgrammerArtResourcePack((AbstractPackResources) packFactory.open(name), getProgrammerArtModResourcePacks());
	}

	/**
	 * {@return} all baked-in mod resource packs that provide Programmer Art resources.
	 */
	private static List<ModResourcePack> getProgrammerArtModResourcePacks() {
		List<ModResourcePack> packs = new ArrayList<>();
		ModResourcePackUtil.appendModResourcePacks(packs, PackType.CLIENT_RESOURCES, "programmer_art");
		return packs;
	}
}
