/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.object.builder.v1.block;

import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockAccessor;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockSettingsAccessor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;

/**
 * Fabric's version of Block.Settings. Adds additional methods and hooks
 * not found in the original class.
 *
 * <p>Make note that this behaves slightly different from the
 * vanilla counterpart, copying some settings that vanilla does not.
 *
 * <p>To use it, simply replace Block.Settings.of() with
 * FabricBlockSettings.of().
 */
public class FabricBlockSettings extends BlockBehaviour.Properties {
	protected FabricBlockSettings(Material material, MaterialColor color) {
		super(material, color);
	}

	protected FabricBlockSettings(Material material, Function<BlockState, MaterialColor> mapColorProvider) {
		super(material, mapColorProvider);
	}

	protected FabricBlockSettings(BlockBehaviour.Properties settings) {
		super(((AbstractBlockSettingsAccessor) settings).getMaterial(), ((AbstractBlockSettingsAccessor) settings).getMapColorProvider());
		// Mostly Copied from vanilla's copy method
		// Note: If new methods are added to Block settings, an accessor must be added here
		AbstractBlockSettingsAccessor thisAccessor = (AbstractBlockSettingsAccessor) this;
		AbstractBlockSettingsAccessor otherAccessor = (AbstractBlockSettingsAccessor) settings;

		// Copied in vanilla: sorted by vanilla copy order
		thisAccessor.setMaterial(otherAccessor.getMaterial());
		this.destroyTime(otherAccessor.getHardness());
		this.explosionResistance(otherAccessor.getResistance());
		this.collidable(otherAccessor.getCollidable());
		thisAccessor.setRandomTicks(otherAccessor.getRandomTicks());
		this.lightLevel(otherAccessor.getLuminance());
		thisAccessor.setMapColorProvider(otherAccessor.getMapColorProvider());
		this.sound(otherAccessor.getSoundGroup());
		this.friction(otherAccessor.getSlipperiness());
		this.speedFactor(otherAccessor.getVelocityMultiplier());
		thisAccessor.setDynamicBounds(otherAccessor.getDynamicBounds());
		thisAccessor.setOpaque(otherAccessor.getOpaque());
		thisAccessor.setIsAir(otherAccessor.getIsAir());
		thisAccessor.setToolRequired(otherAccessor.isToolRequired());
		this.offsetType(otherAccessor.getOffsetType());
		thisAccessor.setBlockBreakParticles(otherAccessor.getBlockBreakParticles());
		thisAccessor.setRequiredFeatures(otherAccessor.getRequiredFeatures());

		// Not copied in vanilla: field definition order
		this.jumpFactor(otherAccessor.getJumpVelocityMultiplier());
		this.drops(otherAccessor.getLootTableId());
		this.isValidSpawn(otherAccessor.getAllowsSpawningPredicate());
		this.isRedstoneConductor(otherAccessor.getSolidBlockPredicate());
		this.isSuffocating(otherAccessor.getSuffocationPredicate());
		this.isViewBlocking(otherAccessor.getBlockVisionPredicate());
		this.hasPostProcess(otherAccessor.getPostProcessPredicate());
		this.emissiveRendering(otherAccessor.getEmissiveLightingPredicate());
	}

	public static FabricBlockSettings of(Material material) {
		return of(material, material.getColor());
	}

	public static FabricBlockSettings of(Material material, MaterialColor color) {
		return new FabricBlockSettings(material, color);
	}

	public static FabricBlockSettings of(Material material, DyeColor color) {
		return new FabricBlockSettings(material, color.getMaterialColor());
	}

	public static FabricBlockSettings of(Material material, Function<BlockState, MaterialColor> mapColor) {
		return new FabricBlockSettings(material, mapColor);
	}

	public static FabricBlockSettings copyOf(BlockBehaviour block) {
		return new FabricBlockSettings(((AbstractBlockAccessor) block).getSettings());
	}

	public static FabricBlockSettings copyOf(BlockBehaviour.Properties settings) {
		return new FabricBlockSettings(settings);
	}

	@Override
	public FabricBlockSettings noCollission() {
		super.noCollission();
		return this;
	}

	@Override
	public FabricBlockSettings noOcclusion() {
		super.noOcclusion();
		return this;
	}

	@Override
	public FabricBlockSettings friction(float value) {
		super.friction(value);
		return this;
	}

	@Override
	public FabricBlockSettings speedFactor(float velocityMultiplier) {
		super.speedFactor(velocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings jumpFactor(float jumpVelocityMultiplier) {
		super.jumpFactor(jumpVelocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings sound(SoundType group) {
		super.sound(group);
		return this;
	}

	/**
	 * @deprecated Please use {@link FabricBlockSettings#lightLevel(ToIntFunction)}.
	 */
	@Deprecated
	public FabricBlockSettings lightLevel(ToIntFunction<BlockState> levelFunction) {
		return this.lightLevel(levelFunction);
	}

	@Override
	public FabricBlockSettings lightLevel(ToIntFunction<BlockState> luminanceFunction) {
		super.lightLevel(luminanceFunction);
		return this;
	}

	@Override
	public FabricBlockSettings strength(float hardness, float resistance) {
		super.strength(hardness, resistance);
		return this;
	}

	@Override
	public FabricBlockSettings instabreak() {
		super.instabreak();
		return this;
	}

	public FabricBlockSettings strength(float strength) {
		super.strength(strength);
		return this;
	}

	@Override
	public FabricBlockSettings randomTicks() {
		super.randomTicks();
		return this;
	}

	@Override
	public FabricBlockSettings dynamicShape() {
		super.dynamicShape();
		return this;
	}

	@Override
	public FabricBlockSettings noLootTable() {
		super.noLootTable();
		return this;
	}

	@Override
	public FabricBlockSettings dropsLike(Block block) {
		super.dropsLike(block);
		return this;
	}

	@Override
	public FabricBlockSettings air() {
		super.air();
		return this;
	}

	@Override
	public FabricBlockSettings isValidSpawn(BlockBehaviour.StateArgumentPredicate<EntityType<?>> predicate) {
		super.isValidSpawn(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings isRedstoneConductor(BlockBehaviour.StatePredicate predicate) {
		super.isRedstoneConductor(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings isSuffocating(BlockBehaviour.StatePredicate predicate) {
		super.isSuffocating(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings isViewBlocking(BlockBehaviour.StatePredicate predicate) {
		super.isViewBlocking(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings hasPostProcess(BlockBehaviour.StatePredicate predicate) {
		super.hasPostProcess(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings emissiveRendering(BlockBehaviour.StatePredicate predicate) {
		super.emissiveRendering(predicate);
		return this;
	}

	/**
	 * Make the block require tool to drop and slows down mining speed if the incorrect tool is used.
	 */
	@Override
	public FabricBlockSettings requiresCorrectToolForDrops() {
		super.requiresCorrectToolForDrops();
		return this;
	}

	@Override
	public FabricBlockSettings color(MaterialColor color) {
		super.color(color);
		return this;
	}

	@Override
	public FabricBlockSettings destroyTime(float hardness) {
		super.destroyTime(hardness);
		return this;
	}

	@Override
	public FabricBlockSettings explosionResistance(float resistance) {
		super.explosionResistance(resistance);
		return this;
	}

	@Override
	public FabricBlockSettings offsetType(BlockBehaviour.OffsetType offsetType) {
		super.offsetType(offsetType);
		return this;
	}

	@Override
	public FabricBlockSettings offsetType(Function<BlockState, BlockBehaviour.OffsetType> offsetType) {
		super.offsetType(offsetType);
		return this;
	}

	@Override
	public FabricBlockSettings noParticlesOnBreak() {
		super.noParticlesOnBreak();
		return this;
	}

	@Override
	public FabricBlockSettings requiredFeatures(FeatureFlag... features) {
		super.requiredFeatures(features);
		return this;
	}

	/* FABRIC ADDITIONS*/

	/**
	 * @deprecated Please use {@link FabricBlockSettings#luminance(int)}.
	 */
	@Deprecated
	public FabricBlockSettings lightLevel(int lightLevel) {
		this.luminance(lightLevel);
		return this;
	}

	public FabricBlockSettings luminance(int luminance) {
		this.lightLevel(ignored -> luminance);
		return this;
	}

	public FabricBlockSettings drops(ResourceLocation dropTableId) {
		((AbstractBlockSettingsAccessor) this).setLootTableId(dropTableId);
		return this;
	}

	/* FABRIC DELEGATE WRAPPERS */

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#color(MaterialColor)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(MaterialColor color) {
		return this.color(color);
	}

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#mapColor(DyeColor)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(DyeColor color) {
		return this.mapColor(color);
	}

	public FabricBlockSettings mapColor(DyeColor color) {
		return this.color(color.getMaterialColor());
	}

	public FabricBlockSettings collidable(boolean collidable) {
		((AbstractBlockSettingsAccessor) this).setCollidable(collidable);
		return this;
	}
}
