/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.client.indigo.renderer;

import java.util.Set;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import net.fabricmc.fabric.impl.client.indigo.renderer.accessor.AccessChunkRendererData;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.chunk.ChunkRenderDispatcher.CompiledChunk;

@Mixin(CompiledChunk.class)
public abstract class MixinChunkRenderData implements AccessChunkRendererData {
	@Shadow
	private Set<RenderType> initializedLayers;
	@Shadow
	private Set<RenderType> nonEmptyLayers;
	@Shadow
	private boolean empty;

	@Override
	public boolean fabric_markInitialized(RenderType renderLayer) {
		return initializedLayers.add(renderLayer);
	}

	@Override
	public void fabric_markPopulated(RenderType renderLayer) {
		empty = false;
		nonEmptyLayers.add(renderLayer);
	}
}
